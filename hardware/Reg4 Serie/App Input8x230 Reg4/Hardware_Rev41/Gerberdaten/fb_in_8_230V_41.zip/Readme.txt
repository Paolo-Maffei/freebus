Generated Gerber files by EAGLE-CAM-Processor:

*.drl Drill rack data
*.drd Excellon drill description
*.dri Excellon drill tool description
*.cmp Component side data
*.sol Solder side data
*.plc Component side silk screen data
*.stc Component side solder stop mask data
*.sts Solder side solder stop mask data
*.gpi Gerber photoplotter information data